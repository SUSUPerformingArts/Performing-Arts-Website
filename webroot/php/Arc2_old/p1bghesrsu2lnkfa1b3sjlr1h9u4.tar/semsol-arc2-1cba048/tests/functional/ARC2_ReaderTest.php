<?php

require_once '../ARC2_TestCase.php';

class ARC2_ReaderTest extends ARC2_TestCase {


	public function testActivate() {
		
		
	}
}
